#ifndef __DVE_LOADER_GAL__
#define __DVE_LOADER_GAL__

#include "its/gal/GAL.hh"


namespace its {

  GAL * loadDve2Gal (Label inputff);

}


#endif
